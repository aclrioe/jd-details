/*window.$=HTMLElement.prototype.$=function(selector){
	return (this==window?document:this).querySelectorAll(selector);
}
window.onload = function(){
	$(".sortchildL")[0].onmouseover = showSort;
	$(".sortchildL")[0].onmouseout = hideSort;

	
	$(".sort_list")[0].onmouseover = function(){
		$(".sl_inner")[0].style.display = "block";
		$(".sl_items")[0].className = "hover";
	}
	$(".sort_list")[0].onmouseout = function(){
		$(".sl_items")[0].style.display = "none";
		$(".sl_items")[0].className = "";
	}
}
function showSl(){
	$(".sl_items")[0].style.display = "block";
}
function hideSl(){
	$(".sl_items")[0].style.display = "none";
}
function showSort(){
	$(".sort_items")[0].style.display = "block";
}
function hideSort(){
	$(".sort_items")[0].style.display = "none";
}*/

/*$().ready(function(){
	$(".sortchildL").mouseover(function(){
        $(".sort_items").css("display","block");
    })
    $(".sortchildL").mouseout(function(){
        $(".sort_items").css("display","none");
    })
    $(".sort_list").first().mouseover(function(){
    	$(".sl_inner").css("display","block");
    	$(".sl_items").first().addClass("hover");
    }).mouseout(function(){
    	$(".sl_inner").css("display","none");
    	$(".sl_items").first().removeClass("hover");
    })
    $(".sort_list").eq(1).mouseover(function(){
    	$(".sl_inner").css("display","block");
    	$(".sl_items").eq(1).addClass("hover");
    }).mouseout(function(){
    	$(".sl_inner").css("display","none");
    	$(".sl_items").eq(1).removeClass("hover");
    })
    $(".sl_items").mouseover(function(){
    	$(".sort_list").eq(1).addClass("slhouver");
    })
});*/